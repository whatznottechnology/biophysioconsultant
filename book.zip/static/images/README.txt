# Image Placeholder
# Please save the practitioner's image as 'pratap.jpeg' in this directory
# The image should be:
# - Named: pratap.jpeg
# - Location: c:\Users\pmihu\OneDrive\Desktop\booking\static\images\pratap.jpeg
# - Recommended size: 400x400 pixels or larger for best quality
# - Format: JPEG

# The image will be displayed in the hero section as a circular profile picture
# with professional styling and a medical badge overlay.